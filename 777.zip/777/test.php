<?php 

phpinfo();